package exercitiu;

public class Square extends Shape{
	
		private int side;
		
		
		public Square(int x, int y, String color, int side) {
			super(x, y, color);
			setSide(side);
		}
		
		public void dimension(int newside) {
			side = newside;
			System.out.println("Sides equal to"+ " " +newside);
		}

		public int getSide() {
			return side;
		}

		public void setSide(int side) {
			this.side = side;
		}
}


