package exercitiu;

public class Circle extends Shape{
	private float radius;
	 
	public Circle(int x, int y, String color, float radius) {
		super(x, y, color);
		setRadius(radius);
	}

	void dimension(float newradius) {
		 this.radius = newradius;
		System.out.println("Radius equal to"+ " " +radius);
	}

	
	public float getRadius() {
		return radius;
	}

	public void setRadius(float radius) {
		this.radius = radius;
	}
}
