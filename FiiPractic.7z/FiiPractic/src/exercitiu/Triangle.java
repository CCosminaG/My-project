package exercitiu;

public class Triangle extends Shape{
	private int base;
	private int side1; 
	private int side2;
	
	
	
	public Triangle(int x, int y, String color, int base, int side1, int side2) {
		super(x, y, color);
		setBase(base);
		setSide1(side1);
		setSide2(side2);
	}
	void dimension(int newbase, int newside1, int newside2) {
		this.base = newbase;
		this.side1 = newside1;
		this.side2 = newside2;
		System.out.println("Base equal to "+this.base+" and sides "+ this.side1 +" and "+this.side2);
		}
	
	
	public int getBase() {
		return base;
	}
	public void setBase(int base) {
		this.base = base;
	}
	public int getSide1() {
		return side1;
	}
	public void setSide1(int side1) {
		this.side1 = side1;
	}
	public int getSide2() {
		return side2;
	}
	public void setSide2(int side2) {
		this.side2 = side2;
	}
}
