package exercitiu;

public class Rectangle extends Shape{
	private int lenght;
	private int width;
	
	
	public Rectangle(int x, int y, String color, int lenght, int width) {
		super(x,y,color);
		setLenght(lenght);
		setWidth(width);
		
	}
	
	void dimension(int newlenght, int newwidth ) {
		 this.lenght = newlenght;
		 this.width = newwidth;
		System.out.println("Lenght equal to"+ " " +newlenght+ " "+"and width to"+ " "+newwidth);
		}

	public int getLenght() {
		return lenght;
	}

	public void setLenght(int lenght) {
		this.lenght = lenght;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}	
}
