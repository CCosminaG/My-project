package exercitiu;

public class Main {

	public static void main(String[] args) {
		Square square1 = new Square(0,0,"red",5);
		Rectangle rectangle1 = new Rectangle(0,0,"balck",10,5);
		Circle circle1 = new Circle (0,0,"grey",3);
		Triangle triangle1 = new Triangle(0,0,"yellow",10,6,6);
		
		square1.position(5,10);
		square1.setColor("brown");
		square1.dimension(6);
		square1.changeColor("red");
		System.out.println(square1.getX()+ " " +square1.getY()+ " " +square1.getColor());
		
		circle1.position(10, 20);
		circle1.dimension(7.1f);
		circle1.changeColor("pink");
		System.out.println(circle1.getColor());
		
	}
}
